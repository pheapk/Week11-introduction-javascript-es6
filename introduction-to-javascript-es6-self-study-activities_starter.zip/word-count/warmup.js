// clone the following array
let a = [1, 2, 3, 4];
// answer
let b = [...a];

// clone an object
let a = { a: 1, b: 2 };
// answer
let b = { ...a };
// clone first n properties of an object

//create a function that returns an array n long with numbers 1 to n
const setArray = (n) => {
  return result;
};
// create a function to sum every other element of an array with
