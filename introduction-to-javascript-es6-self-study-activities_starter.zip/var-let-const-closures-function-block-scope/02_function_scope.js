function userinfo(){
    var age = 20;
    return age;
}
console.log(userinfo());
console.log(age); // error
