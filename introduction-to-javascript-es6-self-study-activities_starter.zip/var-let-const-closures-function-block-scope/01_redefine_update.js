var age = 20;
console.log(age);

age = 30;
console.log(age);

var age = 40;
console.log(age);

// var variables can be updated or redefined
