function userinfo(){
    age = 20;
    return age;
}
console.log(userinfo());
console.log(age); // no error

