for(var i=0; i<5; i++){
    console.log(i);
}
console.log('inspect i:' + i);

for(let i=10; i<15; i++){
    console.log(i);
}
console.log('inspect i:' + i);