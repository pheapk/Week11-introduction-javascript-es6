var age = 20;

if (age > 18){
    var message = 'is adult';
    console.log(message);
}

console.log(message); // no error, global

